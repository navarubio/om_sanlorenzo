/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans.utilidades;

/**
 *
 * @author santos
 */
public class FilaDataTable {

    private String columna1;
    private String columna2;
    private String columna3;
    private String columna4;
    private String columna5;
    private String columna6;
    private String columna7;
    private String columna8;
    private String columna9;
    private String columna10;
    private String columna11;
    private String columna12;
    private String columna13;
    private String columna14;
    private String columna15;    
    private String columna16;
    private String columna17;
    private String columna18;
    private String columna19;
    private String columna20;
    private String columna21;
    private String columna22;
    private String columna23;
    private String columna24;
    private String columna25;
    private String columna26;
    private String columna27;
    private String columna28;
    private String columna29;
    private String columna30;
    private String columna31;
    private String columna32;
    private String columna33;
    private String columna34;
    private String columna35;
    private String columna36;
    private String columna37;
    private String columna38;
    private String columna39;
    private String columna40;
    

    public FilaDataTable() {
    }

    public FilaDataTable(String columna1) {
        this.columna1 = columna1;
    }

    public FilaDataTable(String columna1, String columna2) {
        this.columna1 = columna1;
        this.columna2 = columna2;
    }

    public FilaDataTable(String columna1, String columna2, String columna3) {
        this.columna1 = columna1;
        this.columna2 = columna2;
        this.columna3 = columna3;
    }

    public FilaDataTable(String columna1, String columna2, String columna3, String columna4) {
        this.columna1 = columna1;
        this.columna2 = columna2;
        this.columna3 = columna3;
        this.columna4 = columna4;
    }

    public FilaDataTable(String columna1, String columna2, String columna3, String columna4, String columna5) {
        this.columna1 = columna1;
        this.columna2 = columna2;
        this.columna3 = columna3;
        this.columna4 = columna4;
        this.columna5 = columna5;
    }

    public FilaDataTable(String columna1, String columna2, String columna3, String columna4, String columna5, String columna6) {
        this.columna1 = columna1;
        this.columna2 = columna2;
        this.columna3 = columna3;
        this.columna4 = columna4;
        this.columna5 = columna5;
        this.columna6 = columna6;
    }

    public FilaDataTable(String columna1, String columna2, String columna3, String columna4, String columna5, String columna6, String columna7) {
        this.columna1 = columna1;
        this.columna2 = columna2;
        this.columna3 = columna3;
        this.columna4 = columna4;
        this.columna5 = columna5;
        this.columna6 = columna6;
        this.columna7 = columna7;
    }

    public FilaDataTable(String columna1, String columna2, String columna3, String columna4, String columna5, String columna6, String columna7, String columna8) {
        this.columna1 = columna1;
        this.columna2 = columna2;
        this.columna3 = columna3;
        this.columna4 = columna4;
        this.columna5 = columna5;
        this.columna6 = columna6;
        this.columna7 = columna7;
        this.columna8 = columna8;
    }

    public FilaDataTable(String columna1, String columna2, String columna3, String columna4, String columna5, String columna6, String columna7, String columna8, String columna9) {
        this.columna1 = columna1;
        this.columna2 = columna2;
        this.columna3 = columna3;
        this.columna4 = columna4;
        this.columna5 = columna5;
        this.columna6 = columna6;
        this.columna7 = columna7;
        this.columna8 = columna8;
        this.columna9 = columna9;
    }

    public FilaDataTable(String columna1, String columna2, String columna3, String columna4, String columna5, String columna6, String columna7, String columna8, String columna9, String columna10) {
        this.columna1 = columna1;
        this.columna2 = columna2;
        this.columna3 = columna3;
        this.columna4 = columna4;
        this.columna5 = columna5;
        this.columna6 = columna6;
        this.columna7 = columna7;
        this.columna8 = columna8;
        this.columna9 = columna9;
        this.columna10 = columna10;
    }

    public String getColumna1() {
        System.out.println("Columna 1 = " + columna1);
        return columna1;
    }

    public void setColumna1(String columna1) {
        this.columna1 = columna1;
    }

    public String getColumna2() {
        return columna2;
    }

    public void setColumna2(String columna2) {
        this.columna2 = columna2;
    }

    public String getColumna3() {
        return columna3;
    }

    public void setColumna3(String columna3) {
        this.columna3 = columna3;
    }

    public String getColumna4() {
        return columna4;
    }

    public void setColumna4(String columna4) {
        this.columna4 = columna4;
    }

    public String getColumna5() {
        return columna5;
    }

    public void setColumna5(String columna5) {
        this.columna5 = columna5;
    }

    public String getColumna6() {
        return columna6;
    }

    public void setColumna6(String columna6) {
        this.columna6 = columna6;
    }

    public String getColumna7() {
        return columna7;
    }

    public void setColumna7(String columna7) {
        this.columna7 = columna7;
    }

    public String getColumna8() {
        return columna8;
    }

    public void setColumna8(String columna8) {
        this.columna8 = columna8;
    }

    public String getColumna9() {
        return columna9;
    }

    public void setColumna9(String columna9) {
        this.columna9 = columna9;
    }

    public String getColumna10() {
        return columna10;
    }

    public void setColumna10(String columna10) {
        this.columna10 = columna10;
    }

    public String getColumna11() {
        return columna11;
    }

    public void setColumna11(String columna11) {
        this.columna11 = columna11;
    }

    public String getColumna12() {
        return columna12;
    }

    public void setColumna12(String columna12) {
        this.columna12 = columna12;
    }

    public String getColumna13() {
        return columna13;
    }

    public void setColumna13(String columna13) {
        this.columna13 = columna13;
    }

    public String getColumna14() {
        return columna14;
    }

    public void setColumna14(String columna14) {
        this.columna14 = columna14;
    }

    public String getColumna15() {
        return columna15;
    }

    public void setColumna15(String columna15) {
        this.columna15 = columna15;
    }

    public String getColumna16() {
        return columna16;
    }

    public void setColumna16(String columna16) {
        this.columna16 = columna16;
    }

    public String getColumna17() {
        return columna17;
    }

    public void setColumna17(String columna17) {
        this.columna17 = columna17;
    }

    public String getColumna18() {
        return columna18;
    }

    public void setColumna18(String columna18) {
        this.columna18 = columna18;
    }

    public String getColumna19() {
        return columna19;
    }

    public void setColumna19(String columna19) {
        this.columna19 = columna19;
    }

    public String getColumna20() {
        return columna20;
    }

    public void setColumna20(String columna20) {
        this.columna20 = columna20;
    }

    public String getColumna21() {
        return columna21;
    }

    public void setColumna21(String columna21) {
        this.columna21 = columna21;
    }

    public String getColumna22() {
        return columna22;
    }

    public void setColumna22(String columna22) {
        this.columna22 = columna22;
    }

    public String getColumna23() {
        return columna23;
    }

    public void setColumna23(String columna23) {
        this.columna23 = columna23;
    }

    public String getColumna24() {
        return columna24;
    }

    public void setColumna24(String columna24) {
        this.columna24 = columna24;
    }

    public String getColumna25() {
        return columna25;
    }

    public void setColumna25(String columna25) {
        this.columna25 = columna25;
    }

    public String getColumna26() {
        return columna26;
    }

    public void setColumna26(String columna26) {
        this.columna26 = columna26;
    }

    public String getColumna27() {
        return columna27;
    }

    public void setColumna27(String columna27) {
        this.columna27 = columna27;
    }

    public String getColumna28() {
        return columna28;
    }

    public void setColumna28(String columna28) {
        this.columna28 = columna28;
    }

    public String getColumna29() {
        return columna29;
    }

    public void setColumna29(String columna29) {
        this.columna29 = columna29;
    }

    public String getColumna30() {
        return columna30;
    }

    public void setColumna30(String columna30) {
        this.columna30 = columna30;
    }

    public String getColumna31() {
        return columna31;
    }

    public void setColumna31(String columna31) {
        this.columna31 = columna31;
    }

    public String getColumna32() {
        return columna32;
    }

    public void setColumna32(String columna32) {
        this.columna32 = columna32;
    }

    public String getColumna33() {
        return columna33;
    }

    public void setColumna33(String columna33) {
        this.columna33 = columna33;
    }

    public String getColumna34() {
        return columna34;
    }

    public void setColumna34(String columna34) {
        this.columna34 = columna34;
    }

    public String getColumna35() {
        return columna35;
    }

    public void setColumna35(String columna35) {
        this.columna35 = columna35;
    }

    public String getColumna36() {
        return columna36;
    }

    public void setColumna36(String columna36) {
        this.columna36 = columna36;
    }

    public String getColumna37() {
        return columna37;
    }

    public void setColumna37(String columna37) {
        this.columna37 = columna37;
    }

    public String getColumna38() {
        return columna38;
    }

    public void setColumna38(String columna38) {
        this.columna38 = columna38;
    }

    public String getColumna39() {
        return columna39;
    }

    public void setColumna39(String columna39) {
        this.columna39 = columna39;
    }

    public String getColumna40() {
        return columna40;
    }

    public void setColumna40(String columna40) {
        this.columna40 = columna40;
    }

}
