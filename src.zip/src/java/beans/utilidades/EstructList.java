/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans.utilidades;

/**
 *
 * @author santos
 */
public class EstructList {

    //Estructura que representa lista de 50 campos, Desde XHTML si se usa un 
    //Array o String[n] funciona el metodo get() pero falla cuando invoca el metodo set() 
    private String campo0 = "";
    private String campo1 = "";
    private String campo2 = "";
    private String campo3 = "";
    private String campo4 = "";
    private String campo5 = "";
    private String campo6 = "";
    private String campo7 = "";
    private String campo8 = "";
    private String campo9 = "";
    private String campo10 = "";
    private String campo11 = "";
    private String campo12 = "";
    private String campo13 = "";
    private String campo14 = "";
    private String campo15 = "";
    private String campo16 = "";
    private String campo17 = "";
    private String campo18 = "";
    private String campo19 = "";
    private String campo20 = "";
    private String campo21 = "";
    private String campo22 = "";
    private String campo23 = "";
    private String campo24 = "";
    private String campo25 = "";
    private String campo26 = "";
    private String campo27 = "";
    private String campo28 = "";
    private String campo29 = "";
    private String campo30 = "";
    private String campo31 = "";
    private String campo32 = "";
    private String campo33 = "";
    private String campo34 = "";
    private String campo35 = "";
    private String campo36 = "";
    private String campo37 = "";
    private String campo38 = "";
    private String campo39 = "";
    private String campo40 = "";
    private String campo41 = "";
    private String campo42 = "";
    private String campo43 = "";
    private String campo44 = "";
    private String campo45 = "";
    private String campo46 = "";
    private String campo47 = "";
    private String campo48 = "";
    private String campo49 = "";
    private String campo50 = "";

    public EstructList() {
    }

    public void setValor(int pos, String valor) {
        switch (pos) {
            case 0:
                campo0 = valor;
                break;
            case 1:
                campo1 = valor;
                break;
            case 2:
                campo2 = valor;
                break;
            case 3:
                campo3 = valor;
                break;
            case 4:
                campo4 = valor;
                break;
            case 5:
                campo5 = valor;
                break;
            case 6:
                campo6 = valor;
                break;
            case 7:
                campo7 = valor;
                break;
            case 8:
                campo8 = valor;
                break;
            case 9:
                campo9 = valor;
                break;
            case 10:
                campo10 = valor;
                break;
            case 11:
                campo11 = valor;
                break;
            case 12:
                campo12 = valor;
                break;
            case 13:
                campo13 = valor;
                break;
            case 14:
                campo14 = valor;
                break;
            case 15:
                campo15 = valor;
                break;
            case 16:
                campo16 = valor;
                break;
            case 17:
                campo17 = valor;
                break;
            case 18:
                campo18 = valor;
                break;
            case 19:
                campo19 = valor;
                break;
            case 20:
                campo20 = valor;
                break;
            case 21:
                campo21 = valor;
                break;
            case 22:
                campo22 = valor;
                break;
            case 23:
                campo23 = valor;
                break;
            case 24:
                campo24 = valor;
                break;
            case 25:
                campo25 = valor;
                break;
            case 26:
                campo26 = valor;
                break;
            case 27:
                campo27 = valor;
                break;
            case 28:
                campo28 = valor;
                break;
            case 29:
                campo29 = valor;
                break;
            case 30:
                campo30 = valor;
                break;
            case 31:
                campo31 = valor;
                break;
            case 32:
                campo32 = valor;
                break;
            case 33:
                campo33 = valor;
                break;
            case 34:
                campo34 = valor;
                break;
            case 35:
                campo35 = valor;
                break;
            case 36:
                campo36 = valor;
                break;
            case 37:
                campo37 = valor;
                break;
            case 38:
                campo38 = valor;
                break;
            case 39:
                campo39 = valor;
                break;
            case 40:
                campo40 = valor;
                break;
            case 41:
                campo41 = valor;
                break;
            case 42:
                campo42 = valor;
                break;
            case 43:
                campo43 = valor;
                break;
            case 44:
                campo44 = valor;
                break;
            case 45:
                campo45 = valor;
                break;
            case 46:
                campo46 = valor;
                break;
            case 47:
                campo47 = valor;
                break;
            case 48:
                campo48 = valor;
                break;
            case 49:
                campo49 = valor;
                break;
            case 50:
                campo50 = valor;
                break;
        }
    }

    public String getValor(int pos) {
        switch (pos) {
            case 0:
                return campo0;
            case 1:
                return campo1;
            case 2:
                return campo2;
            case 3:
                return campo3;
            case 4:
                return campo4;
            case 5:
                return campo5;
            case 6:
                return campo6;
            case 7:
                return campo7;
            case 8:
                return campo8;
            case 9:
                return campo9;
            case 10:
                return campo10;
            case 11:
                return campo11;
            case 12:
                return campo12;
            case 13:
                return campo13;
            case 14:
                return campo14;
            case 15:
                return campo15;
            case 16:
                return campo16;
            case 17:
                return campo17;
            case 18:
                return campo18;
            case 19:
                return campo19;
            case 20:
                return campo20;
            case 21:
                return campo21;
            case 22:
                return campo22;
            case 23:
                return campo23;
            case 24:
                return campo24;
            case 25:
                return campo25;
            case 26:
                return campo26;
            case 27:
                return campo27;
            case 28:
                return campo28;
            case 29:
                return campo29;
            case 30:
                return campo30;
            case 31:
                return campo31;
            case 32:
                return campo32;
            case 33:
                return campo33;
            case 34:
                return campo34;
            case 35:
                return campo35;
            case 36:
                return campo36;
            case 37:
                return campo37;
            case 38:
                return campo38;
            case 39:
                return campo39;
            case 40:
                return campo40;
            case 41:
                return campo41;
            case 42:
                return campo42;
            case 43:
                return campo43;
            case 44:
                return campo44;
            case 45:
                return campo45;
            case 46:
                return campo46;
            case 47:
                return campo47;
            case 48:
                return campo48;
            case 49:
                return campo49;
            case 50:
                return campo50;
        }
        return null;
    }

    public void limpiar() {
        campo0 = "";
        campo1 = "";
        campo2 = "";
        campo3 = "";
        campo4 = "";
        campo5 = "";
        campo6 = "";
        campo7 = "";
        campo8 = "";
        campo9 = "";
        campo10 = "";
        campo11 = "";
        campo12 = "";
        campo13 = "";
        campo14 = "";
        campo15 = "";
        campo16 = "";
        campo17 = "";
        campo18 = "";
        campo19 = "";
        campo20 = "";
        campo21 = "";
        campo22 = "";
        campo23 = "";
        campo24 = "";
        campo25 = "";
        campo26 = "";
        campo27 = "";
        campo28 = "";
        campo29 = "";
        campo30 = "";
        campo31 = "";
        campo32 = "";
        campo33 = "";
        campo34 = "";
        campo35 = "";
        campo36 = "";
        campo37 = "";
        campo38 = "";
        campo39 = "";
        campo40 = "";
        campo41 = "";
        campo42 = "";
        campo43 = "";
        campo44 = "";
        campo45 = "";
        campo46 = "";
        campo47 = "";
        campo48 = "";
        campo49 = "";
        campo50 = "";
    }

    public String getCampo0() {
        return campo0;
    }

    public void setCampo0(String campo0) {
        this.campo0 = campo0;
    }

    public String getCampo1() {
        return campo1;
    }

    public void setCampo1(String campo1) {
        this.campo1 = campo1;
    }

    public String getCampo2() {
        return campo2;
    }

    public void setCampo2(String campo2) {
        this.campo2 = campo2;
    }

    public String getCampo3() {
        return campo3;
    }

    public void setCampo3(String campo3) {
        this.campo3 = campo3;
    }

    public String getCampo4() {
        return campo4;
    }

    public void setCampo4(String campo4) {
        this.campo4 = campo4;
    }

    public String getCampo5() {
        return campo5;
    }

    public void setCampo5(String campo5) {
        this.campo5 = campo5;
    }

    public String getCampo6() {
        return campo6;
    }

    public void setCampo6(String campo6) {
        this.campo6 = campo6;
    }

    public String getCampo7() {
        return campo7;
    }

    public void setCampo7(String campo7) {
        this.campo7 = campo7;
    }

    public String getCampo8() {
        return campo8;
    }

    public void setCampo8(String campo8) {
        this.campo8 = campo8;
    }

    public String getCampo9() {
        return campo9;
    }

    public void setCampo9(String campo9) {
        this.campo9 = campo9;
    }

    public String getCampo10() {
        return campo10;
    }

    public void setCampo10(String campo10) {
        this.campo10 = campo10;
    }

    public String getCampo11() {
        return campo11;
    }

    public void setCampo11(String campo11) {
        this.campo11 = campo11;
    }

    public String getCampo12() {
        return campo12;
    }

    public void setCampo12(String campo12) {
        this.campo12 = campo12;
    }

    public String getCampo13() {
        return campo13;
    }

    public void setCampo13(String campo13) {
        this.campo13 = campo13;
    }

    public String getCampo14() {
        return campo14;
    }

    public void setCampo14(String campo14) {
        this.campo14 = campo14;
    }

    public String getCampo15() {
        return campo15;
    }

    public void setCampo15(String campo15) {
        this.campo15 = campo15;
    }

    public String getCampo16() {
        return campo16;
    }

    public void setCampo16(String campo16) {
        this.campo16 = campo16;
    }

    public String getCampo17() {
        return campo17;
    }

    public void setCampo17(String campo17) {
        this.campo17 = campo17;
    }

    public String getCampo18() {
        return campo18;
    }

    public void setCampo18(String campo18) {
        this.campo18 = campo18;
    }

    public String getCampo19() {
        return campo19;
    }

    public void setCampo19(String campo19) {
        this.campo19 = campo19;
    }

    public String getCampo20() {
        return campo20;
    }

    public void setCampo20(String campo20) {
        this.campo20 = campo20;
    }

    public String getCampo21() {
        return campo21;
    }

    public void setCampo21(String campo21) {
        this.campo21 = campo21;
    }

    public String getCampo22() {
        return campo22;
    }

    public void setCampo22(String campo22) {
        this.campo22 = campo22;
    }

    public String getCampo23() {
        return campo23;
    }

    public void setCampo23(String campo23) {
        this.campo23 = campo23;
    }

    public String getCampo24() {
        return campo24;
    }

    public void setCampo24(String campo24) {
        this.campo24 = campo24;
    }

    public String getCampo25() {
        return campo25;
    }

    public void setCampo25(String campo25) {
        this.campo25 = campo25;
    }

    public String getCampo26() {
        return campo26;
    }

    public void setCampo26(String campo26) {
        this.campo26 = campo26;
    }

    public String getCampo27() {
        return campo27;
    }

    public void setCampo27(String campo27) {
        this.campo27 = campo27;
    }

    public String getCampo28() {
        return campo28;
    }

    public void setCampo28(String campo28) {
        this.campo28 = campo28;
    }

    public String getCampo29() {
        return campo29;
    }

    public void setCampo29(String campo29) {
        this.campo29 = campo29;
    }

    public String getCampo30() {
        return campo30;
    }

    public void setCampo30(String campo30) {
        this.campo30 = campo30;
    }

    public String getCampo31() {
        return campo31;
    }

    public void setCampo31(String campo31) {
        this.campo31 = campo31;
    }

    public String getCampo32() {
        return campo32;
    }

    public void setCampo32(String campo32) {
        this.campo32 = campo32;
    }

    public String getCampo33() {
        return campo33;
    }

    public void setCampo33(String campo33) {
        this.campo33 = campo33;
    }

    public String getCampo34() {
        return campo34;
    }

    public void setCampo34(String campo34) {
        this.campo34 = campo34;
    }

    public String getCampo35() {
        return campo35;
    }

    public void setCampo35(String campo35) {
        this.campo35 = campo35;
    }

    public String getCampo36() {
        return campo36;
    }

    public void setCampo36(String campo36) {
        this.campo36 = campo36;
    }

    public String getCampo37() {
        return campo37;
    }

    public void setCampo37(String campo37) {
        this.campo37 = campo37;
    }

    public String getCampo38() {
        return campo38;
    }

    public void setCampo38(String campo38) {
        this.campo38 = campo38;
    }

    public String getCampo39() {
        return campo39;
    }

    public void setCampo39(String campo39) {
        this.campo39 = campo39;
    }

    public String getCampo40() {
        return campo40;
    }

    public void setCampo40(String campo40) {
        this.campo40 = campo40;
    }

    public String getCampo41() {
        return campo41;
    }

    public void setCampo41(String campo41) {
        this.campo41 = campo41;
    }

    public String getCampo42() {
        return campo42;
    }

    public void setCampo42(String campo42) {
        this.campo42 = campo42;
    }

    public String getCampo43() {
        return campo43;
    }

    public void setCampo43(String campo43) {
        this.campo43 = campo43;
    }

    public String getCampo44() {
        return campo44;
    }

    public void setCampo44(String campo44) {
        this.campo44 = campo44;
    }

    public String getCampo45() {
        return campo45;
    }

    public void setCampo45(String campo45) {
        this.campo45 = campo45;
    }

    public String getCampo46() {
        return campo46;
    }

    public void setCampo46(String campo46) {
        this.campo46 = campo46;
    }

    public String getCampo47() {
        return campo47;
    }

    public void setCampo47(String campo47) {
        this.campo47 = campo47;
    }

    public String getCampo48() {
        return campo48;
    }

    public void setCampo48(String campo48) {
        this.campo48 = campo48;
    }

    public String getCampo49() {
        return campo49;
    }

    public void setCampo49(String campo49) {
        this.campo49 = campo49;
    }

    public String getCampo50() {
        return campo50;
    }

    public void setCampo50(String campo50) {
        this.campo50 = campo50;
    }

}
